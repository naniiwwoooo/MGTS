"""Разбор комментариев: тема, тональность и цитата-обоснование.

Режимы:
  * ИИ (LLM_PROVIDER=anthropic | openai | gigachat) - модель сама выбирает тему из фиксированного списка;
  * правила (запасной вариант) - ключевые слова + оценка. Работает без интернета и ключей.

Если вызов ИИ не удался, соответствующая пачка комментариев обрабатывается правилами,
поэтому дашборд работает всегда.

В модель уходят только текст комментария, вопрос и оценка. Имена и id людей не отправляются.
"""

import json
import re

import pandas as pd
import requests

from src import config

THEMES = [
    "нагрузка",
    "обратная связь",
    "атмосфера в команде",
    "задачи и приоритеты",
    "адаптация и обучение",
    "другое",
]
SENTIMENTS = ["негативная", "нейтральная", "позитивная"]

# Подсказка по теме, если в комментарии нет ключевых слов
QUESTION_THEME = {
    "Нагрузка": "нагрузка",
    "Качество обратной связи": "обратная связь",
    "Атмосфера в команде": "атмосфера в команде",
    "Понятность задач": "задачи и приоритеты",
    "Адаптация в компании": "адаптация и обучение",
}

KEYWORDS = {
    "нагрузка": ["нагруз", "не успева", "не успевает", "дедлайн", "вечер", "переработ", "задержива", "много задач", "срочн"],
    "обратная связь": ["обратн", "разбор", "разбира", "оценк", "не понимаю, что делаю", "похвал"],
    "атмосфера в команде": ["атмосфер", "команд", "руководител", "напряж", "общают", "боюсь", "холодн", "конфликт", "поддержк"],
    "задачи и приоритеты": ["задач", "приоритет", "результат", "контекст", "расплывчат", "пояснен"],
    "адаптация и обучение": ["адаптац", "вводн", "процесс", "обучен", "разобраться", "освоил", "онбординг"],
}

BATCH_SIZE = 20
KEY = ["role", "person_id", "wave", "question"]


# --- Правила -----------------------------------------------------------------
def sentiment_by_score(score: float) -> str:
    if score <= 2:
        return "негативная"
    if score >= 4:
        return "позитивная"
    return "нейтральная"


def analyze_by_rules(comment: str, score: float, question: str) -> dict:
    text = comment.lower()
    hits = {theme: sum(1 for kw in kws if kw in text) for theme, kws in KEYWORDS.items()}
    best = max(hits, key=hits.get)
    theme = best if hits[best] > 0 else QUESTION_THEME.get(question, "другое")
    return {
        "theme": theme,
        "sentiment": sentiment_by_score(score),
        "evidence": comment[:160],
        "method": "rules",
    }


# --- ИИ ----------------------------------------------------------------------
def llm_enabled() -> bool:
    if config.LLM_PROVIDER == "gigachat":
        return bool(config.GIGACHAT_CREDENTIALS)
    return (
        config.LLM_PROVIDER in ("anthropic", "openai")
        and bool(config.LLM_API_KEY)
        and bool(config.LLM_MODEL)
    )


def _call_gigachat(prompt: str) -> str:
    """Вызов GigaChat через официальный SDK. Токен обновляется автоматически."""
    try:
        from gigachat import GigaChat
    except ImportError as exc:
        raise RuntimeError(
            "Библиотека gigachat не установлена. Выполните: pip install gigachat"
        ) from exc

    with GigaChat(
        credentials=config.GIGACHAT_CREDENTIALS,
        model=config.GIGACHAT_MODEL,
        verify_ssl_certs=False,
    ) as giga:
        response = giga.chat(prompt)
        return response.choices[0].message.content


def _call_llm(prompt: str) -> str:
    if config.LLM_PROVIDER == "gigachat":
        return _call_gigachat(prompt)

    if config.LLM_PROVIDER == "anthropic":
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": config.LLM_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": config.LLM_MODEL,
                "max_tokens": 3000,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=60,
        )
        response.raise_for_status()
        return "".join(block.get("text", "") for block in response.json()["content"])

    # openai-совместимый API (Groq, OpenAI, OpenRouter и т.д.)
    response = requests.post(
        config.LLM_BASE_URL.rstrip("/") + "/chat/completions",
        headers={"Authorization": f"Bearer {config.LLM_API_KEY}"},
        json={
            "model": config.LLM_MODEL,
            "temperature": 0,
            "messages": [{"role": "user", "content": prompt}],
        },
        timeout=60,
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]


def _build_prompt(items: list[dict]) -> str:
    return (
        "Ты помогаешь HR анализировать комментарии стажёров и наставников из анкет.\n"
        "Для каждого комментария верни:\n"
        f"- theme: одна тема из списка {json.dumps(THEMES, ensure_ascii=False)};\n"
        f"- sentiment: одно из {json.dumps(SENTIMENTS, ensure_ascii=False)};\n"
        "- evidence: короткая цитата, скопированная из комментария дословно (до 120 символов).\n"
        "Не придумывай факты, которых нет в комментарии.\n"
        "Ответь ТОЛЬКО JSON-массивом без пояснений и без markdown, формат:\n"
        '[{"id": 0, "theme": "...", "sentiment": "...", "evidence": "..."}]\n\n'
        "Комментарии:\n" + json.dumps(items, ensure_ascii=False)
    )


def _parse_json_array(text: str) -> list[dict]:
    start, end = text.find("["), text.rfind("]")
    if start == -1 or end == -1:
        raise ValueError("В ответе модели нет JSON-массива")
    return json.loads(text[start : end + 1])


def analyze_batch_llm(items: list[dict]) -> dict:
    """items: [{id, question, score, comment}]. Возвращает {id: результат}."""
    raw = _call_llm(_build_prompt(items))
    by_id = {it["id"]: it for it in items}
    result = {}
    for row in _parse_json_array(raw):
        item = by_id.get(row.get("id"))
        if item is None:
            continue
        theme = row.get("theme") if row.get("theme") in THEMES else "другое"
        sentiment = row.get("sentiment") if row.get("sentiment") in SENTIMENTS else sentiment_by_score(item["score"])
        evidence = str(row.get("evidence", "")).strip()
        if not evidence or evidence not in item["comment"]:
            evidence = item["comment"][:160]  # цитата должна быть реальной
        result[item["id"]] = {"theme": theme, "sentiment": sentiment, "evidence": evidence, "method": "llm"}
    return result


# --- Основная функция --------------------------------------------------------
def analyze_new(df: pd.DataFrame, done_keys: set) -> pd.DataFrame:
    """Анализирует комментарии, которых ещё нет в базе анализа."""
    cols = KEY + ["theme", "sentiment", "evidence", "method"]
    rows = []
    for r in df[df["comment"] != ""].itertuples():
        if (r.role, r.person_id, str(r.wave), r.question) not in done_keys:
            rows.append(r)
    if not rows:
        return pd.DataFrame(columns=cols)

    out = []
    use_llm = llm_enabled()
    for start in range(0, len(rows), BATCH_SIZE):
        batch = rows[start : start + BATCH_SIZE]
        items = [
            {"id": i, "question": r.question, "score": float(r.score), "comment": r.comment}
            for i, r in enumerate(batch)
        ]
        llm_result = {}
        if use_llm:
            try:
                llm_result = analyze_batch_llm(items)
            except Exception as err:  # сеть, ключ, формат ответа - неважно, есть запасной вариант
                print(f"Анализ через ИИ не удался, используем правила: {err}")
        for i, r in enumerate(batch):
            res = llm_result.get(i) or analyze_by_rules(r.comment, float(r.score), r.question)
            out.append(
                {
                    "role": r.role,
                    "person_id": r.person_id,
                    "wave": r.wave.item() if hasattr(r.wave, "item") else r.wave,
                    "question": r.question,
                    **res,
                }
            )
    return pd.DataFrame(out, columns=cols)
