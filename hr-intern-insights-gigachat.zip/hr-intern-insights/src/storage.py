"""Хранилище на SQLite: ответы анкет, результаты анализа комментариев, служебные данные."""

import sqlite3
from contextlib import contextmanager

import pandas as pd

from src import config

KEY = ["role", "person_id", "wave", "question"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS responses (
    role TEXT NOT NULL,
    person_id TEXT NOT NULL,
    wave NUMERIC NOT NULL,
    question TEXT NOT NULL,
    department TEXT,
    score REAL,
    comment TEXT,
    PRIMARY KEY (role, person_id, wave, question)
);
CREATE TABLE IF NOT EXISTS comment_analysis (
    role TEXT NOT NULL,
    person_id TEXT NOT NULL,
    wave NUMERIC NOT NULL,
    question TEXT NOT NULL,
    theme TEXT,
    sentiment TEXT,
    evidence TEXT,
    method TEXT,
    PRIMARY KEY (role, person_id, wave, question)
);
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


@contextmanager
def connect():
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _py(value):
    """numpy-значения -> обычные типы Python (SQLite не принимает numpy)."""
    return value.item() if hasattr(value, "item") else value


def init_db():
    with connect() as conn:
        conn.executescript(SCHEMA)


def save_responses(df: pd.DataFrame):
    cols = ["role", "person_id", "wave", "question", "department", "score", "comment"]
    rows = [tuple(_py(v) for v in row) for row in df[cols].itertuples(index=False, name=None)]
    with connect() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO responses (role, person_id, wave, question, department, score, comment) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            rows,
        )


def load_responses() -> pd.DataFrame:
    with connect() as conn:
        df = pd.read_sql_query(
            "SELECT role, person_id, wave, question, department, score, comment "
            "FROM responses ORDER BY rowid",
            conn,
        )
    df["comment"] = df["comment"].fillna("")
    return df


def save_analysis(df: pd.DataFrame):
    if df is None or df.empty:
        return
    cols = KEY + ["theme", "sentiment", "evidence", "method"]
    rows = [tuple(_py(v) for v in row) for row in df[cols].itertuples(index=False, name=None)]
    with connect() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO comment_analysis "
            "(role, person_id, wave, question, theme, sentiment, evidence, method) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            rows,
        )


def load_analysis() -> pd.DataFrame:
    with connect() as conn:
        return pd.read_sql_query(
            "SELECT role, person_id, wave, question, theme, sentiment, evidence, method "
            "FROM comment_analysis",
            conn,
        )


def analyzed_keys() -> set:
    df = load_analysis()
    return {(r.role, r.person_id, str(r.wave), r.question) for r in df.itertuples()}


def set_meta(key: str, value: str):
    with connect() as conn:
        conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (key, value))


def get_meta(key: str, default=None):
    with connect() as conn:
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default
