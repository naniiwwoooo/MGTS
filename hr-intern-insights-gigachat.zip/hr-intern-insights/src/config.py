"""Настройки проекта. Значения берутся из файла .env (см. .env.example)."""

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # python-dotenv не обязателен
    load_dotenv = None

BASE_DIR = Path(__file__).resolve().parent.parent
if load_dotenv:
    load_dotenv(BASE_DIR / ".env")


def _env(name, default=""):
    return os.getenv(name, default).strip()


# --- Источник данных ---------------------------------------------------------
# csv  - читаем файлы из data/sample (для разработки)
# mock - имитация внешнего API (данные приходят как JSON-записи)
# http - настоящий внешний сервис анкетирования (нужны API_URL и API_TOKEN)
SURVEY_SOURCE = _env("SURVEY_SOURCE", "csv")
INTERNS_CSV = BASE_DIR / "data" / "sample" / "interns.csv"
MENTORS_CSV = BASE_DIR / "data" / "sample" / "mentors.csv"
API_URL = _env("API_URL")
API_TOKEN = _env("API_TOKEN")

# Автообновление данных раз в N минут (0 - выключено)
REFRESH_MINUTES = int(_env("REFRESH_MINUTES", "0") or 0)

# --- Хранилище ---------------------------------------------------------------
DB_PATH = BASE_DIR / _env("DB_PATH", "data/app.db")

# --- Пороги сигналов (можно менять на странице «Сигналы») --------------------
# На реальных данных с большим числом ответов MIN_N стоит поднять до 3-5
MIN_N = int(_env("MIN_N", "2") or 2)
DROP_THR = float(_env("DROP_THR", "0.75") or 0.75)
GAP_THR = float(_env("GAP_THR", "0.7") or 0.7)

# --- ИИ для комментариев -----------------------------------------------------
# none      - только правила (работает без интернета и ключей)
# anthropic - Claude через API
# openai    - любой OpenAI-совместимый API (задайте LLM_BASE_URL)
# gigachat  - GigaChat от Сбера (нужен GIGACHAT_CREDENTIALS)
LLM_PROVIDER = _env("LLM_PROVIDER", "none").lower()
LLM_API_KEY = _env("LLM_API_KEY")
LLM_MODEL = _env("LLM_MODEL")
LLM_BASE_URL = _env("LLM_BASE_URL", "https://api.openai.com/v1")

# GigaChat (Сбер). Сюда кладётся Authorization Key из кабинета разработчика.
GIGACHAT_CREDENTIALS = _env("GIGACHAT_CREDENTIALS")
# Модель по умолчанию. Можно сменить на GigaChat-Pro / GigaChat-Max, если есть доступ.
GIGACHAT_MODEL = _env("GIGACHAT_MODEL", "GigaChat")
