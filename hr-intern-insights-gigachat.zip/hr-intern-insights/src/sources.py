"""Источники анкет. Всё приложение работает с одной таблицей, а не с конкретным сервисом.

Колонки единой таблицы:
    person_id, role (intern|mentor), department, wave, question, score, comment

Чтобы подключить настоящий сервис анкетирования, достаточно:
  1) указать API_URL и API_TOKEN в .env, SURVEY_SOURCE=http
  2) поправить FIELD_MAP ниже под названия полей в ответе сервиса
"""

from abc import ABC, abstractmethod
from pathlib import Path

import pandas as pd

from src import config

COLUMNS = ["person_id", "role", "department", "wave", "question", "score", "comment"]
REQUIRED = ["person_id", "department", "wave", "question", "score"]

ROLE_ALIASES = {
    "intern": "intern",
    "стажёр": "intern",
    "стажер": "intern",
    "mentor": "mentor",
    "наставник": "mentor",
}

# наше название столбца -> название поля в ответе внешнего сервиса
FIELD_MAP = {
    "person_id": "person_id",
    "role": "role",
    "department": "department",
    "wave": "wave",
    "question": "question",
    "score": "score",
    "comment": "comment",
}


def normalize(df: pd.DataFrame, role: str | None = None) -> pd.DataFrame:
    """Приводит любую выгрузку к единой таблице и чистит данные."""
    df = df.copy()
    if role is not None:
        df["role"] = role
    if "role" not in df.columns:
        raise ValueError("В данных нет столбца role (intern/mentor)")
    if "comment" not in df.columns:
        df["comment"] = ""

    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"В данных нет столбцов: {', '.join(missing)}")

    df["role"] = df["role"].astype(str).str.strip().str.lower().map(ROLE_ALIASES)
    if df["role"].isna().any():
        raise ValueError("Неизвестное значение role: допустимы intern/mentor (или стажёр/наставник)")

    # Оценки: запятая -> точка, мусор -> пропуск, строки без оценки отбрасываем
    df["score"] = pd.to_numeric(
        df["score"].astype(str).str.replace(",", ".", regex=False).str.strip(),
        errors="coerce",
    )
    df = df.dropna(subset=["score"])

    # Волны: числа, если все значения числовые, иначе текст
    waves = pd.to_numeric(df["wave"], errors="coerce")
    df["wave"] = waves.astype(int) if waves.notna().all() else df["wave"].astype(str)

    df["person_id"] = df["person_id"].astype(str).str.strip()
    df["department"] = df["department"].fillna("Не указан").astype(str)
    df["question"] = df["question"].astype(str).str.strip()
    df["comment"] = df["comment"].fillna("").astype(str).str.strip()
    return df[COLUMNS].reset_index(drop=True)


class SurveySource(ABC):
    @abstractmethod
    def fetch_responses(self, since=None) -> pd.DataFrame:
        """Возвращает единую таблицу ответов (см. COLUMNS)."""


class CsvSource(SurveySource):
    """Читает data/sample/interns.csv и mentors.csv."""

    def fetch_responses(self, since=None) -> pd.DataFrame:
        frames = []
        for path, role in ((config.INTERNS_CSV, "intern"), (config.MENTORS_CSV, "mentor")):
            if Path(path).exists():
                frames.append(normalize(pd.read_csv(path), role=role))
        if not frames:
            raise FileNotFoundError(f"Не найдены файлы данных: {config.INTERNS_CSV}")
        return pd.concat(frames, ignore_index=True)


class ApiSource(SurveySource):
    """Общая логика для сервисов, которые отдают JSON-записи."""

    field_map = FIELD_MAP

    def fetch_raw(self, since=None) -> list[dict]:
        raise NotImplementedError

    def fetch_responses(self, since=None) -> pd.DataFrame:
        records = self.fetch_raw(since)
        df = pd.DataFrame(records)
        df = df.rename(columns={v: k for k, v in self.field_map.items()})
        return normalize(df)


class MockApiSource(ApiSource):
    """Имитация внешнего сервиса: отдаёт данные из CSV в виде списка JSON-записей."""

    def fetch_raw(self, since=None) -> list[dict]:
        return CsvSource().fetch_responses().to_dict("records")


class HttpApiSource(ApiSource):
    """Настоящий внешний сервис анкетирования. Подстройте под его документацию."""

    def fetch_raw(self, since=None) -> list[dict]:
        import requests

        if not config.API_URL:
            raise ValueError("Не задан API_URL в .env")
        headers = {"Authorization": f"Bearer {config.API_TOKEN}"} if config.API_TOKEN else {}
        params = {"since": since} if since else {}
        response = requests.get(config.API_URL, headers=headers, params=params, timeout=20)
        response.raise_for_status()
        data = response.json()
        # Если сервис оборачивает записи в {"results": [...]}, достаём их
        if isinstance(data, dict):
            data = data.get("results", data.get("data", []))
        return data


def get_source() -> SurveySource:
    sources = {"csv": CsvSource, "mock": MockApiSource, "http": HttpApiSource}
    if config.SURVEY_SOURCE not in sources:
        raise ValueError(f"Неизвестный SURVEY_SOURCE: {config.SURVEY_SOURCE}")
    return sources[config.SURVEY_SOURCE]()
