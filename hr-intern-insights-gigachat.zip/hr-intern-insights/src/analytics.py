"""Расчёты для дашборда: общая картина, динамика, расхождения, профиль стажёра."""

import pandas as pd

ROLE_RU = {"intern": "стажёры", "mentor": "наставники"}


def wave_order(df: pd.DataFrame) -> list:
    """Числовые волны по возрастанию, текстовые в порядке появления."""
    uniq = list(dict.fromkeys(df["wave"].tolist()))
    if all(isinstance(w, (int, float)) for w in uniq):
        return sorted(uniq)
    return uniq


def _round(value):
    return None if value is None or pd.isna(value) else round(float(value), 2)


def to_series(pivot: pd.DataFrame, order: list) -> dict:
    """Таблица волна x группа -> словарь для графика (None там, где нет данных)."""
    pivot = pivot.reindex(order)
    return {str(col): [_round(v) for v in pivot[col]] for col in pivot.columns}


def overview(df: pd.DataFrame, order: list) -> dict:
    last = df[df["wave"] == order[-1]]["score"].mean() if order else None
    prev = df[df["wave"] == order[-2]]["score"].mean() if len(order) > 1 else None
    return {
        "responses": int(len(df)),
        "interns": int(df[df["role"] == "intern"]["person_id"].nunique()),
        "mentors": int(df[df["role"] == "mentor"]["person_id"].nunique()),
        "waves": len(order),
        "avg_last": _round(last),
        "delta": _round(last - prev) if prev is not None and last is not None else None,
    }


def dynamics_by_role(df: pd.DataFrame, order: list) -> dict:
    pivot = df.pivot_table(index="wave", columns="role", values="score", aggfunc="mean")
    pivot = pivot.rename(columns=ROLE_RU)
    return to_series(pivot, order)


def dynamics_by_question(df: pd.DataFrame, order: list, role: str = "intern") -> dict:
    d = df[df["role"] == role]
    pivot = d.pivot_table(index="wave", columns="question", values="score", aggfunc="mean")
    return to_series(pivot, order)


def question_table(df: pd.DataFrame, gap_thr: float) -> list[dict]:
    """По каждому вопросу: оценка стажёров, наставников, разница."""
    rows = []
    for question, g in df.groupby("question"):
        i = g[g["role"] == "intern"]["score"]
        m = g[g["role"] == "mentor"]["score"]
        gap = (i.mean() - m.mean()) if len(i) and len(m) else None
        rows.append(
            {
                "question": question,
                "intern": _round(i.mean()) if len(i) else None,
                "mentor": _round(m.mean()) if len(m) else None,
                "gap": _round(gap),
                "big_gap": gap is not None and abs(gap) >= gap_thr,
                "n": int(len(g)),
            }
        )
    return sorted(rows, key=lambda r: r["question"])


def intern_list(df: pd.DataFrame, order: list, flagged_ids: set) -> list[dict]:
    """Таблица стажёров: последняя оценка, изменение, наличие сигнала."""
    rows = []
    d = df[df["role"] == "intern"]
    for pid, g in d.groupby("person_id"):
        by_wave = g.groupby("wave")["score"].mean().reindex(order).dropna()
        last = by_wave.iloc[-1] if len(by_wave) else None
        prev = by_wave.iloc[-2] if len(by_wave) > 1 else None
        rows.append(
            {
                "person_id": pid,
                "department": g["department"].iloc[0],
                "last": _round(last),
                "delta": _round(last - prev) if last is not None and prev is not None else None,
                "flag": pid in flagged_ids,
            }
        )
    return sorted(rows, key=lambda r: (r["delta"] is None, r["delta"] if r["delta"] is not None else 0))


def intern_profile(dfa: pd.DataFrame, pid: str, order: list):
    """Профиль стажёра: динамика, сравнение с отделом, комментарии. dfa = ответы + анализ комментариев."""
    d = dfa[(dfa["role"] == "intern") & (dfa["person_id"] == pid)]
    if d.empty:
        return None
    dept = d["department"].iloc[0]
    waves = [w for w in order if w in set(d["wave"])]
    last_w = waves[-1]
    prev_w = waves[-2] if len(waves) > 1 else None

    others = dfa[(dfa["role"] == "intern") & (dfa["department"] == dept) & (dfa["person_id"] != pid)]
    mentors = dfa[(dfa["role"] == "mentor") & (dfa["department"] == dept)]

    def mean_at(frame, question, wave):
        s = frame[(frame["question"] == question) & (frame["wave"] == wave)]["score"]
        return _round(s.mean()) if len(s) else None

    table = []
    for question in sorted(d["question"].unique()):
        last = mean_at(d, question, last_w)
        prev = mean_at(d, question, prev_w) if prev_w is not None else None
        table.append(
            {
                "question": question,
                "last": last,
                "prev": prev,
                "delta": _round(last - prev) if last is not None and prev is not None else None,
                "dept_interns": mean_at(others, question, last_w),
                "dept_mentors": mean_at(mentors, question, last_w),
            }
        )

    pivot = d.pivot_table(index="wave", columns="question", values="score", aggfunc="mean")
    comments = d[d["comment"] != ""].copy()
    comments["wave_sort"] = comments["wave"].map({w: i for i, w in enumerate(order)})
    comments = comments.sort_values("wave_sort", ascending=False)
    comment_rows = [
        {
            "wave": r.wave,
            "question": r.question,
            "score": _round(r.score),
            "comment": r.comment,
            "theme": r.theme if isinstance(r.theme, str) else None,
            "sentiment": r.sentiment if isinstance(r.sentiment, str) else None,
        }
        for r in comments.itertuples()
    ]

    avg_all = d.groupby("wave")["score"].mean().reindex(order)
    return {
        "person_id": pid,
        "department": dept,
        "last_wave": last_w,
        "series": to_series(pivot, order),
        "chart": {"Среднее": [_round(v) for v in avg_all], **to_series(pivot, order)},
        "table": table,
        "comments": comment_rows,
        "avg_last": _round(d[d["wave"] == last_w]["score"].mean()),
        "avg_dept_interns": _round(others[others["wave"] == last_w]["score"].mean()) if len(others) else None,
        "avg_dept_mentors": _round(mentors[mentors["wave"] == last_w]["score"].mean()) if len(mentors) else None,
    }
