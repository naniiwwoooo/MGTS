"""Сигналы: простые понятные правила + доказательства из комментариев.

Правила намеренно прозрачные (пороги меняются на странице «Сигналы»).
ИИ используется не для поиска сигнала, а для объяснения его причины по комментариям.
"""

import pandas as pd

from src.analytics import ROLE_RU

MIN_QUESTIONS_FOR_PERSON = 3  # сколько вопросов должно быть у стажёра, чтобы считать его среднюю


def _severity(value: float, strong: float = 1.0) -> str:
    return "high" if abs(value) >= strong else "medium"


def _evidence(dfa, department, question=None, wave=None, role="intern", person_id=None, max_score=3, limit=2):
    """Комментарии с низкими оценками по теме сигнала: главная тема и до двух цитат."""
    d = dfa[(dfa["role"] == role) & (dfa["department"] == department)]
    d = d[(d["score"] <= max_score) & (d["comment"] != "")]
    if question is not None:
        d = d[d["question"] == question]
    if wave is not None:
        d = d[d["wave"] == wave]
    if person_id is not None:
        d = d[d["person_id"] == person_id]
    if d.empty:
        return {"theme": None, "quotes": []}

    themes = d["theme"].dropna()
    theme = themes.value_counts().index[0] if len(themes) else None
    quotes = []
    for r in d.itertuples():
        quote = r.evidence if isinstance(r.evidence, str) and r.evidence else r.comment
        if quote not in quotes:
            quotes.append(quote)
        if len(quotes) >= limit:
            break
    return {"theme": theme, "quotes": quotes}


def _reason(ev: dict) -> str:
    if ev["quotes"]:
        theme = f"Чаще всего в комментариях: {ev['theme']}." if ev["theme"] else "Комментарии при низких оценках:"
        return theme
    return "Комментариев при низких оценках нет, причину по данным установить нельзя."


def drop_signals(dfa, order, drop_thr, min_n):
    """Падение средней оценки в последней волне по сравнению с предыдущей (отдельно для стажёров и наставников)."""
    signals = []
    if len(order) < 2:
        return signals
    prev_w, last_w = order[-2], order[-1]
    for role in ("intern", "mentor"):
        d = dfa[(dfa["role"] == role) & (dfa["wave"].isin([prev_w, last_w]))]
        g = d.groupby(["department", "question", "wave"])["score"].agg(["mean", "count"]).reset_index()
        for (dep, question), grp in g.groupby(["department", "question"]):
            p = grp[grp["wave"] == prev_w]
            l = grp[grp["wave"] == last_w]
            if p.empty or l.empty or p["count"].iloc[0] < min_n or l["count"].iloc[0] < min_n:
                continue
            before, after = float(p["mean"].iloc[0]), float(l["mean"].iloc[0])
            delta = after - before
            if delta > -drop_thr:
                continue
            ev = _evidence(dfa, dep, question=question, wave=last_w, role=role)
            signals.append(
                {
                    "kind": "drop",
                    "severity": _severity(delta),
                    "magnitude": abs(delta),
                    "department": dep,
                    "question": question,
                    "title": f"Падение оценки: {question}",
                    "subtitle": f"{dep}, {ROLE_RU[role]}",
                    "detail": f"С {before:.2f} до {after:.2f} ({delta:+.2f}) в волне {last_w}. Ответов: {int(l['count'].iloc[0])}.",
                    "reason": _reason(ev),
                    "quotes": ev["quotes"],
                    "person_id": None,
                }
            )
    return signals


def gap_signals(dfa, gap_thr, min_n):
    """Расхождение между оценками стажёров и наставников по вопросу в отделе (за все волны)."""
    signals = []
    g = dfa.groupby(["department", "question", "role"])["score"].agg(["mean", "count"]).reset_index()
    for (dep, question), grp in g.groupby(["department", "question"]):
        i = grp[grp["role"] == "intern"]
        m = grp[grp["role"] == "mentor"]
        if i.empty or m.empty or min(i["count"].iloc[0], m["count"].iloc[0]) < min_n:
            continue
        mi, mm = float(i["mean"].iloc[0]), float(m["mean"].iloc[0])
        diff = mi - mm
        if abs(diff) < gap_thr:
            continue
        ev = _evidence(dfa, dep, question=question, role="intern")
        who = "стажёры оценивают ниже наставников" if diff < 0 else "стажёры оценивают выше наставников"
        signals.append(
            {
                "kind": "gap",
                "severity": _severity(diff, strong=1.2),
                "magnitude": abs(diff),
                "department": dep,
                "question": question,
                "title": f"Расхождение мнений: {question}",
                "subtitle": f"{dep}, {who}",
                "detail": f"Стажёры {mi:.2f}, наставники {mm:.2f}, разница {diff:+.2f}.",
                "reason": _reason(ev),
                "quotes": ev["quotes"],
                "person_id": None,
            }
        )
    return signals


def person_signals(dfa, order, drop_thr):
    """Стажёры с заметным падением в последнем опросе.

    Сигнал, если упала средняя оценка ИЛИ по одному вопросу оценка упала сильно (от 2 порогов).
    """
    signals = []
    if len(order) < 2:
        return signals
    prev_w, last_w = order[-2], order[-1]
    d = dfa[dfa["role"] == "intern"]
    for pid, g in d.groupby("person_id"):
        p = g[g["wave"] == prev_w]
        l = g[g["wave"] == last_w]
        if len(p) < MIN_QUESTIONS_FOR_PERSON or len(l) < MIN_QUESTIONS_FOR_PERSON:
            continue
        before, after = float(p["score"].mean()), float(l["score"].mean())
        delta = after - before
        by_q = (l.set_index("question")["score"] - p.set_index("question")["score"]).dropna()
        worst = by_q.idxmin() if len(by_q) else None
        worst_drop = float(by_q.min()) if len(by_q) else 0.0
        if delta > -drop_thr and worst_drop > -2 * drop_thr:
            continue
        dep = g["department"].iloc[0]
        ev = _evidence(dfa, dep, wave=last_w, person_id=pid)
        extra = ""
        if worst is not None and worst_drop < 0:
            then = float(p.set_index("question").loc[worst, "score"])
            now = float(l.set_index("question").loc[worst, "score"])
            extra = f" Сильнее всего упал вопрос «{worst}»: с {then:.0f} до {now:.0f}."
        signals.append(
            {
                "kind": "person",
                "severity": _severity(max(abs(delta), abs(worst_drop) / 2)),
                "magnitude": max(abs(delta), abs(worst_drop) / 2),
                "department": dep,
                "question": worst,
                "title": f"Стажёр {pid}: оценка упала",
                "subtitle": dep,
                "detail": f"Средняя оценка с {before:.2f} до {after:.2f} ({delta:+.2f}) в волне {last_w}." + extra,
                "reason": _reason(ev),
                "quotes": ev["quotes"],
                "person_id": pid,
            }
        )
    return signals


def all_signals(dfa, order, drop_thr, gap_thr, min_n):
    signals = drop_signals(dfa, order, drop_thr, min_n) + gap_signals(dfa, gap_thr, min_n) + person_signals(dfa, order, drop_thr)
    signals.sort(key=lambda s: (s["severity"] != "high", -s["magnitude"]))
    return signals
