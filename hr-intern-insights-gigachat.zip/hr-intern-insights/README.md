# HR Intern Insights

Веб-дашборд для HR: автоматически получает результаты ежемесячных опросов стажёров и наставников,
разбирает оценки и комментарии (в том числе с помощью ИИ), показывает динамику, находит потенциальные
проблемы и позволяет открыть детали по каждому стажёру.

Стек: Python (Flask, pandas, SQLite) + HTML/CSS. Графики: Chart.js (лежит локально, интернет не нужен).

## Запуск (Windows, PowerShell, из корня проекта)

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python app/main.py
```

Откройте http://127.0.0.1:5000

При первом запуске данные берутся из `data/sample/*.csv` и сохраняются в `data/app.db`.
Кнопка «Обновить данные» в шапке заново получает ответы из источника и разбирает новые комментарии.

## Как это устроено

```
Источник анкет -> src/sources.py -> SQLite (src/storage.py)
                                      |
        src/analytics.py (динамика, расхождения, профиль стажёра)
        src/signals.py   (правила сигналов + доказательства из комментариев)
        src/comments_ai.py (ИИ или правила: тема, тональность, цитата)
                                      |
                       app/main.py (Flask) -> app/templates + app/static
```

Вся система работает с одной таблицей: `person_id, role, department, wave, question, score, comment`.
Источник данных можно заменить, не трогая остальной код.

## Что настраивается в .env

| Переменная | Что делает |
|---|---|
| SURVEY_SOURCE | csv (файлы), mock (имитация API), http (настоящий сервис) |
| API_URL, API_TOKEN | адрес и ключ внешнего сервиса анкетирования (для http) |
| REFRESH_MINUTES | автообновление раз в N минут, 0 - выключено |
| MIN_N, DROP_THR, GAP_THR | пороги сигналов (их же можно менять на странице «Сигналы») |
| LLM_PROVIDER | none (правила), anthropic, openai или gigachat |
| LLM_API_KEY, LLM_MODEL, LLM_BASE_URL | доступ к модели (для anthropic/openai) |
| GIGACHAT_CREDENTIALS, GIGACHAT_MODEL | доступ к GigaChat (Сбер) |

## Подключение настоящего сервиса анкетирования

1. В `.env`: `SURVEY_SOURCE=http`, заполнить `API_URL` и `API_TOKEN`.
2. В `src/sources.py` поправить `FIELD_MAP` под названия полей в ответе сервиса.
3. Если авторизация или формат ответа другие, правится только `HttpApiSource.fetch_raw`.

## Подключение ИИ для комментариев

В `.env` задайте `LLM_PROVIDER` и соответствующие ключи. Модель выбирает тему из фиксированного
списка и возвращает цитату из комментария. Если вызов не удался, комментарии обрабатываются правилами,
поэтому дашборд работает всегда. В модель уходят только текст комментария, вопрос и оценка, без имён и id.

### GigaChat (Сбер)

1. Получите Authorization Key на https://developers.sber.ru/
2. В `.env`:
   ```
   LLM_PROVIDER=gigachat
   GIGACHAT_CREDENTIALS=ваш_authorization_key
   GIGACHAT_MODEL=GigaChat
   ```
3. Установите библиотеку: `pip install gigachat`
4. Перезапустите приложение и нажмите «Обновить данные».

## Сигналы

- Падение оценки: в последнем опросе оценка по вопросу в отделе упала на пороговое значение и больше.
- Расхождение мнений: стажёры и наставники по-разному оценивают один вопрос в отделе.
- Отдельный стажёр: упала средняя оценка или резко упала оценка по одному вопросу.

К каждому сигналу показываются главная тема и цитаты из комментариев при низких оценках.
Если комментариев нет, причина не придумывается.

## Структура файлов

```
app/main.py              маршруты Flask, обновление данных
app/templates/           страницы (base, index, signals, intern, empty, _signal)
app/static/              style.css, charts.js, vendor/chart.umd.js
src/                     config, sources, storage, analytics, signals, comments_ai
data/sample/             синтетические данные (5 стажёров, 5 наставников, 6 опросов)
```
