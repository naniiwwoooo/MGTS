// Линейные графики на Chart.js (библиотека лежит локально в static/vendor, интернет не нужен)
const PALETTE = ["#1b4f8a", "#b42318", "#0f766e", "#9a5b00", "#6d3fb3", "#0e7490"];

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function lineChart(canvasId, labels, series, colors) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || typeof Chart === "undefined") return;

  Chart.defaults.color = cssVar("--muted");
  Chart.defaults.borderColor = cssVar("--line");
  Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;

  const datasets = Object.entries(series).map(([name, values], i) => {
    const isAverage = name === "Среднее";
    const color = isAverage ? cssVar("--ink") : (colors && colors[name]) || PALETTE[i % PALETTE.length];
    return {
      label: name,
      data: values,
      borderColor: color,
      backgroundColor: color,
      borderWidth: isAverage ? 3 : 2,
      borderDash: isAverage ? [6, 4] : [],
      pointRadius: 3,
      tension: 0.2,
      spanGaps: true,
    };
  });

  new Chart(canvas, {
    type: "line",
    data: { labels: labels, datasets: datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      scales: {
        y: { min: 1, max: 5, ticks: { stepSize: 1 }, title: { display: true, text: "Средняя оценка" } },
        x: { title: { display: true, text: "Номер опроса" } },
      },
      plugins: { legend: { position: "bottom" } },
    },
  });
}
