"""Веб-приложение HR Intern Insights (Flask).

Запуск из корня проекта:
    python app/main.py
Затем откройте http://127.0.0.1:5000
"""

import sys
import threading
import time
from datetime import datetime
from pathlib import Path

# Чтобы работал импорт пакета src при запуске `python app/main.py`
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from flask import Flask, abort, flash, redirect, render_template, request, url_for  # noqa: E402

from src import analytics, comments_ai, config, signals, sources, storage  # noqa: E402

app = Flask(__name__, root_path=str(Path(__file__).resolve().parent))
app.secret_key = "hr-intern-insights-dev"  # нужен только для сообщений flash


# ---------------------------------------------------------------------------
# Данные
# ---------------------------------------------------------------------------
def refresh_data():
    """Получает ответы из источника, сохраняет в SQLite и анализирует новые комментарии."""
    df = sources.get_source().fetch_responses()
    storage.save_responses(df)
    all_df = storage.load_responses()
    new_analysis = comments_ai.analyze_new(all_df, storage.analyzed_keys())
    storage.save_analysis(new_analysis)
    storage.set_meta("last_update", datetime.now().strftime("%d.%m.%Y %H:%M"))
    return len(df), len(new_analysis)


def get_data():
    """Возвращает (ответы, ответы + анализ комментариев)."""
    df = storage.load_responses()
    analysis = storage.load_analysis()
    dfa = df.merge(analysis, on=storage.KEY, how="left")
    return df, dfa


def _float_arg(name, default):
    try:
        return float(request.args.get(name, default))
    except (TypeError, ValueError):
        return default


def _int_arg(name, default):
    try:
        return max(1, int(request.args.get(name, default)))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Шаблоны: общие данные и фильтры
# ---------------------------------------------------------------------------
@app.context_processor
def inject_globals():
    return {
        "last_update": storage.get_meta("last_update"),
        "llm_on": comments_ai.llm_enabled(),
        "source_name": config.SURVEY_SOURCE,
    }


@app.template_filter("num")
def num_filter(value, digits=2):
    if value is None or value != value:
        return "—"
    return f"{value:.{digits}f}"


@app.template_filter("delta")
def delta_filter(value):
    if value is None or value != value:
        return "—"
    return f"{value:+.2f}"


@app.template_filter("trend")
def trend_filter(value):
    if value is None or value != value or abs(value) < 0.05:
        return "flat"
    return "up" if value > 0 else "down"


# ---------------------------------------------------------------------------
# Страницы
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    df, dfa = get_data()
    if df.empty:
        return render_template("empty.html", active="index")

    departments = sorted(df["department"].unique())
    dept = request.args.get("dept", "")
    if dept in departments:
        df = df[df["department"] == dept]
        dfa = dfa[dfa["department"] == dept]
    else:
        dept = ""

    order = analytics.wave_order(df)
    found = signals.all_signals(dfa, order, config.DROP_THR, config.GAP_THR, config.MIN_N)
    flagged = {s["person_id"] for s in found if s["kind"] == "person"}

    return render_template(
        "index.html",
        active="index",
        departments=departments,
        dept=dept,
        labels=[str(w) for w in order],
        kpi=analytics.overview(df, order),
        series_role=analytics.dynamics_by_role(df, order),
        series_question=analytics.dynamics_by_question(df, order, "intern"),
        questions=analytics.question_table(df, config.GAP_THR),
        top_signals=[s for s in found if s["kind"] != "person"][:6],
        signals_total=len(found),
        interns=analytics.intern_list(df, order, flagged),
    )


@app.route("/signals")
def signals_page():
    df, dfa = get_data()
    min_n = _int_arg("min_n", config.MIN_N)
    drop_thr = _float_arg("drop", config.DROP_THR)
    gap_thr = _float_arg("gap", config.GAP_THR)
    order = analytics.wave_order(df) if not df.empty else []
    found = signals.all_signals(dfa, order, drop_thr, gap_thr, min_n) if order else []
    return render_template(
        "signals.html",
        active="signals",
        found=found,
        min_n=min_n,
        drop_thr=drop_thr,
        gap_thr=gap_thr,
    )


@app.route("/intern/<pid>")
def intern_page(pid):
    df, dfa = get_data()
    if df.empty:
        abort(404)
    order = analytics.wave_order(df)
    profile = analytics.intern_profile(dfa, pid, order)
    if profile is None:
        abort(404)
    own_signals = [
        s
        for s in signals.all_signals(dfa, order, config.DROP_THR, config.GAP_THR, config.MIN_N)
        if s["person_id"] == pid
    ]
    return render_template(
        "intern.html",
        active="index",
        p=profile,
        labels=[str(w) for w in order],
        own_signals=own_signals,
    )


@app.route("/refresh", methods=["POST"])
def refresh():
    try:
        total, analyzed = refresh_data()
        flash(f"Данные обновлены: получено ответов {total}, новых комментариев разобрано {analyzed}.")
    except Exception as err:  # показываем причину на странице, а не падаем
        flash(f"Не удалось обновить данные: {err}")
    return redirect(request.referrer or url_for("index"))


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def _auto_refresh_loop():
    while True:
        time.sleep(config.REFRESH_MINUTES * 60)
        try:
            refresh_data()
        except Exception as err:
            print(f"Автообновление не удалось: {err}")


def prepare():
    storage.init_db()
    if storage.load_responses().empty:
        try:
            refresh_data()
        except Exception as err:
            print(f"Первичная загрузка не удалась: {err}")
    if config.REFRESH_MINUTES > 0:
        threading.Thread(target=_auto_refresh_loop, daemon=True).start()


if __name__ == "__main__":
    prepare()
    app.run(debug=True, use_reloader=False)
