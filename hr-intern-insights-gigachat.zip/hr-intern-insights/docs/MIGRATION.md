# Переход со Streamlit на Flask: что убрать, что добавить

Текущий проект: app/dashboard.py (Streamlit), data/sample/interns.csv, .gitignore, .env, README.md.

## 0. Подготовка
1. Закоммитьте текущее состояние (`git add . && git commit -m "before flask"`), чтобы можно было вернуться.
2. Остановите запущенный Streamlit (Ctrl+C в терминале).

## 1. Что убрать
- `app/dashboard.py`: старый Streamlit-дашборд. Вся логика (оценки, динамика, расхождения, сигналы)
  перенесена в `src/analytics.py` и `src/signals.py`.
- Из `requirements.txt` строку `streamlit` (файл заменяется целиком, см. ниже).
- Из README команду `streamlit run app/dashboard.py` (README заменяется).
- По желанию: `pip uninstall streamlit`.

## 2. Что добавить (скопируйте из архива с сохранением папок)
- `app/main.py`, `app/templates/*`, `app/static/*` (включая `vendor/chart.umd.js`)
- `src/*` (все 7 файлов, включая пустой `__init__.py`)
- `requirements.txt`, `.env.example`, `.gitignore`, `README.md`
- `data/sample/mentors.csv` (если ещё нет) и актуальный `data/sample/interns.csv`

## 3. Что оставить как есть
- `.venv/`, `.env` (ключи), данные в `data/sample/`.
- Файл `.env` после копирования `.env.example` проверьте: там появились новые переменные
  (SURVEY_SOURCE, REFRESH_MINUTES, MIN_N и т.д.). Свои ключи не стирайте.

## 4. Установка и запуск
```
.venv\Scripts\activate
pip install -r requirements.txt
python app/main.py
```
Откройте http://127.0.0.1:5000

## 5. Если что-то пошло не так
- ModuleNotFoundError: No module named 'src': запускайте из корня проекта командой `python app/main.py`
  и проверьте, что в папке `src` есть файл `__init__.py`.
- Страница пустая: нажмите «Обновить данные» и проверьте наличие `data/sample/interns.csv`.
- Хотите начать с чистой базой: остановите сервер и удалите `data/app.db`.

## 6. Коммит
```
git add .
git commit -m "Flask dashboard: sources, storage, analytics, signals, comments AI"
git push
```
